﻿namespace TH08___Clothes_Shop
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.topWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bottomWearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accesoriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelleriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.othersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgv_total = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.btn_add_pants3 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.lb_pants3 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_add_pants2 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_pants2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btn_add_pants1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.lb_pants1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_add_shirt3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.lb_shirt3 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btn_add_shirt2 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.lb_shirt2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.btn_add_shirt1 = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.lb_shirt1 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_add_lpants3 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.lb_lpants3 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.btn_add_lpants2 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.lb_lpants2 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.btn_add_lpants1 = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.lb_lpants1 = new System.Windows.Forms.Label();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.panel_lpants = new System.Windows.Forms.Panel();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.btn_add_tshirt3 = new System.Windows.Forms.Button();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.lb_tshirt1 = new System.Windows.Forms.Label();
            this.lb_tshirt3 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.btn_add_tshirt1 = new System.Windows.Forms.Button();
            this.btn_add_tshirt2 = new System.Windows.Forms.Button();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lb_tshirt2 = new System.Windows.Forms.Label();
            this.btn_add_jewel3 = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.lb_jewel3 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.btn_add_jewel2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.lb_jewel2 = new System.Windows.Forms.Label();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.btn_add_jewel1 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.lb_jewel1 = new System.Windows.Forms.Label();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.panel_jewel = new System.Windows.Forms.Panel();
            this.btn_add_shoes3 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.lb_shoes3 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.btn_add_shoes2 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.lb_shoes2 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.btn_add_shoes1 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.lb_shoes1 = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_add_others = new System.Windows.Forms.Button();
            this.tb_itemprice = new System.Windows.Forms.TextBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.pBox_upload = new System.Windows.Forms.PictureBox();
            this.btn_upload = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.panel_others = new System.Windows.Forms.Panel();
            this.btn_delete = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_total)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.panel_lpants.SuspendLayout();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.panel_jewel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_upload)).BeginInit();
            this.panel_others.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.topWearToolStripMenuItem,
            this.bottomWearToolStripMenuItem,
            this.accesoriesToolStripMenuItem,
            this.othersToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1170, 33);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // topWearToolStripMenuItem
            // 
            this.topWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.topWearToolStripMenuItem.Name = "topWearToolStripMenuItem";
            this.topWearToolStripMenuItem.Size = new System.Drawing.Size(102, 29);
            this.topWearToolStripMenuItem.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // bottomWearToolStripMenuItem
            // 
            this.bottomWearToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.bottomWearToolStripMenuItem.Name = "bottomWearToolStripMenuItem";
            this.bottomWearToolStripMenuItem.Size = new System.Drawing.Size(133, 29);
            this.bottomWearToolStripMenuItem.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // accesoriesToolStripMenuItem
            // 
            this.accesoriesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelleriesToolStripMenuItem});
            this.accesoriesToolStripMenuItem.Name = "accesoriesToolStripMenuItem";
            this.accesoriesToolStripMenuItem.Size = new System.Drawing.Size(111, 29);
            this.accesoriesToolStripMenuItem.Text = "Accesories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(183, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelleriesToolStripMenuItem
            // 
            this.jewelleriesToolStripMenuItem.Name = "jewelleriesToolStripMenuItem";
            this.jewelleriesToolStripMenuItem.Size = new System.Drawing.Size(183, 34);
            this.jewelleriesToolStripMenuItem.Text = "Jewellery";
            this.jewelleriesToolStripMenuItem.Click += new System.EventHandler(this.jewelleriesToolStripMenuItem_Click);
            // 
            // othersToolStripMenuItem
            // 
            this.othersToolStripMenuItem.Name = "othersToolStripMenuItem";
            this.othersToolStripMenuItem.Size = new System.Drawing.Size(81, 29);
            this.othersToolStripMenuItem.Text = "Others";
            this.othersToolStripMenuItem.Click += new System.EventHandler(this.othersToolStripMenuItem_Click);
            // 
            // dgv_total
            // 
            this.dgv_total.AllowUserToAddRows = false;
            this.dgv_total.AllowUserToDeleteRows = false;
            this.dgv_total.AllowUserToResizeColumns = false;
            this.dgv_total.AllowUserToResizeRows = false;
            this.dgv_total.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv_total.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dgv_total.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dgv_total.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_total.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dgv_total.Location = new System.Drawing.Point(537, 53);
            this.dgv_total.Name = "dgv_total";
            this.dgv_total.RowHeadersVisible = false;
            this.dgv_total.RowHeadersWidth = 62;
            this.dgv_total.RowTemplate.Height = 28;
            this.dgv_total.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_total.Size = new System.Drawing.Size(495, 296);
            this.dgv_total.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(532, 358);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sub Total: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(534, 394);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 29);
            this.label2.TabIndex = 3;
            this.label2.Text = "Total: ";
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Location = new System.Drawing.Point(677, 362);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(353, 26);
            this.tb_subtotal.TabIndex = 4;
            // 
            // tb_total
            // 
            this.tb_total.Location = new System.Drawing.Point(677, 394);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(353, 26);
            this.tb_total.TabIndex = 5;
            // 
            // btn_add_pants3
            // 
            this.btn_add_pants3.Location = new System.Drawing.Point(331, 288);
            this.btn_add_pants3.Name = "btn_add_pants3";
            this.btn_add_pants3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_pants3.TabIndex = 47;
            this.btn_add_pants3.Text = "Add Cart";
            this.btn_add_pants3.UseVisualStyleBackColor = true;
            this.btn_add_pants3.Click += new System.EventHandler(this.btn_add_pants3_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(327, 254);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 20);
            this.label5.TabIndex = 46;
            this.label5.Text = "Rp.200.000,-";
            // 
            // lb_pants3
            // 
            this.lb_pants3.AutoSize = true;
            this.lb_pants3.Location = new System.Drawing.Point(327, 221);
            this.lb_pants3.Name = "lb_pants3";
            this.lb_pants3.Size = new System.Drawing.Size(94, 20);
            this.lb_pants3.TabIndex = 45;
            this.lb_pants3.Text = "Retro Pants";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(333, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(149, 166);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 44;
            this.pictureBox3.TabStop = false;
            // 
            // btn_add_pants2
            // 
            this.btn_add_pants2.Location = new System.Drawing.Point(167, 288);
            this.btn_add_pants2.Name = "btn_add_pants2";
            this.btn_add_pants2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_pants2.TabIndex = 43;
            this.btn_add_pants2.Text = "Add Cart";
            this.btn_add_pants2.UseVisualStyleBackColor = true;
            this.btn_add_pants2.Click += new System.EventHandler(this.btn_add_pants2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(163, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(101, 20);
            this.label3.TabIndex = 42;
            this.label3.Text = "Rp.130.000,-";
            // 
            // lb_pants2
            // 
            this.lb_pants2.AutoSize = true;
            this.lb_pants2.Location = new System.Drawing.Point(163, 221);
            this.lb_pants2.Name = "lb_pants2";
            this.lb_pants2.Size = new System.Drawing.Size(90, 20);
            this.lb_pants2.TabIndex = 41;
            this.lb_pants2.Text = "Army Pants";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(173, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(139, 166);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 40;
            this.pictureBox2.TabStop = false;
            // 
            // btn_add_pants1
            // 
            this.btn_add_pants1.Location = new System.Drawing.Point(18, 288);
            this.btn_add_pants1.Name = "btn_add_pants1";
            this.btn_add_pants1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_pants1.TabIndex = 39;
            this.btn_add_pants1.Text = "Add Cart";
            this.btn_add_pants1.UseVisualStyleBackColor = true;
            this.btn_add_pants1.Click += new System.EventHandler(this.btn_add_pants1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 254);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(101, 20);
            this.label4.TabIndex = 38;
            this.label4.Text = "Rp.150.000,-";
            // 
            // lb_pants1
            // 
            this.lb_pants1.AutoSize = true;
            this.lb_pants1.Location = new System.Drawing.Point(14, 221);
            this.lb_pants1.Name = "lb_pants1";
            this.lb_pants1.Size = new System.Drawing.Size(97, 20);
            this.lb_pants1.TabIndex = 37;
            this.lb_pants1.Text = "Cargo Pants";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(18, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(133, 166);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 36;
            this.pictureBox1.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.pictureBox2);
            this.panel_pants.Controls.Add(this.btn_add_pants3);
            this.panel_pants.Controls.Add(this.pictureBox1);
            this.panel_pants.Controls.Add(this.label5);
            this.panel_pants.Controls.Add(this.lb_pants1);
            this.panel_pants.Controls.Add(this.lb_pants3);
            this.panel_pants.Controls.Add(this.label4);
            this.panel_pants.Controls.Add(this.pictureBox3);
            this.panel_pants.Controls.Add(this.btn_add_pants1);
            this.panel_pants.Controls.Add(this.btn_add_pants2);
            this.panel_pants.Controls.Add(this.lb_pants2);
            this.panel_pants.Controls.Add(this.label3);
            this.panel_pants.Location = new System.Drawing.Point(11, 50);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(497, 360);
            this.panel_pants.TabIndex = 48;
            // 
            // btn_add_shirt3
            // 
            this.btn_add_shirt3.Location = new System.Drawing.Point(316, 303);
            this.btn_add_shirt3.Name = "btn_add_shirt3";
            this.btn_add_shirt3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shirt3.TabIndex = 60;
            this.btn_add_shirt3.Text = "Add Cart";
            this.btn_add_shirt3.UseVisualStyleBackColor = true;
            this.btn_add_shirt3.Click += new System.EventHandler(this.btn_add_shirt3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(312, 269);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 20);
            this.label6.TabIndex = 59;
            this.label6.Text = "Rp.120.000,-";
            // 
            // lb_shirt3
            // 
            this.lb_shirt3.AutoSize = true;
            this.lb_shirt3.Location = new System.Drawing.Point(312, 236);
            this.lb_shirt3.Name = "lb_shirt3";
            this.lb_shirt3.Size = new System.Drawing.Size(85, 20);
            this.lb_shirt3.TabIndex = 58;
            this.lb_shirt3.Text = "Shirt Ungu";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(318, 18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(149, 166);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 57;
            this.pictureBox4.TabStop = false;
            // 
            // btn_add_shirt2
            // 
            this.btn_add_shirt2.Location = new System.Drawing.Point(152, 303);
            this.btn_add_shirt2.Name = "btn_add_shirt2";
            this.btn_add_shirt2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shirt2.TabIndex = 56;
            this.btn_add_shirt2.Text = "Add Cart";
            this.btn_add_shirt2.UseVisualStyleBackColor = true;
            this.btn_add_shirt2.Click += new System.EventHandler(this.btn_add_shirt2_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(148, 269);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 20);
            this.label7.TabIndex = 55;
            this.label7.Text = "Rp.110.000,-";
            // 
            // lb_shirt2
            // 
            this.lb_shirt2.AutoSize = true;
            this.lb_shirt2.Location = new System.Drawing.Point(148, 236);
            this.lb_shirt2.Name = "lb_shirt2";
            this.lb_shirt2.Size = new System.Drawing.Size(82, 20);
            this.lb_shirt2.TabIndex = 54;
            this.lb_shirt2.Text = "Shirt Hijau";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(158, 18);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(139, 166);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 53;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // btn_add_shirt1
            // 
            this.btn_add_shirt1.Location = new System.Drawing.Point(3, 303);
            this.btn_add_shirt1.Name = "btn_add_shirt1";
            this.btn_add_shirt1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shirt1.TabIndex = 52;
            this.btn_add_shirt1.Text = "Add Cart";
            this.btn_add_shirt1.UseVisualStyleBackColor = true;
            this.btn_add_shirt1.Click += new System.EventHandler(this.btn_add_shirt1_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(-1, 269);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 20);
            this.label8.TabIndex = 51;
            this.label8.Text = "Rp.100.000,-";
            // 
            // lb_shirt1
            // 
            this.lb_shirt1.AutoSize = true;
            this.lb_shirt1.Location = new System.Drawing.Point(-1, 236);
            this.lb_shirt1.Name = "lb_shirt1";
            this.lb_shirt1.Size = new System.Drawing.Size(74, 20);
            this.lb_shirt1.TabIndex = 50;
            this.lb_shirt1.Text = "Shirt Biru";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(3, 18);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(133, 166);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 49;
            this.pictureBox6.TabStop = false;
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.pictureBox6);
            this.panel_shirt.Controls.Add(this.btn_add_shirt3);
            this.panel_shirt.Controls.Add(this.lb_shirt1);
            this.panel_shirt.Controls.Add(this.label6);
            this.panel_shirt.Controls.Add(this.label8);
            this.panel_shirt.Controls.Add(this.lb_shirt3);
            this.panel_shirt.Controls.Add(this.btn_add_shirt1);
            this.panel_shirt.Controls.Add(this.pictureBox4);
            this.panel_shirt.Controls.Add(this.pictureBox5);
            this.panel_shirt.Controls.Add(this.btn_add_shirt2);
            this.panel_shirt.Controls.Add(this.lb_shirt2);
            this.panel_shirt.Controls.Add(this.label7);
            this.panel_shirt.Location = new System.Drawing.Point(11, 50);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(494, 351);
            this.panel_shirt.TabIndex = 61;
            // 
            // btn_add_lpants3
            // 
            this.btn_add_lpants3.Location = new System.Drawing.Point(316, 285);
            this.btn_add_lpants3.Name = "btn_add_lpants3";
            this.btn_add_lpants3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_lpants3.TabIndex = 73;
            this.btn_add_lpants3.Text = "Add Cart";
            this.btn_add_lpants3.UseVisualStyleBackColor = true;
            this.btn_add_lpants3.Click += new System.EventHandler(this.btn_add_lpants3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(312, 251);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 20);
            this.label9.TabIndex = 72;
            this.label9.Text = "Rp.200.000,-";
            // 
            // lb_lpants3
            // 
            this.lb_lpants3.AutoSize = true;
            this.lb_lpants3.Location = new System.Drawing.Point(312, 218);
            this.lb_lpants3.Name = "lb_lpants3";
            this.lb_lpants3.Size = new System.Drawing.Size(79, 20);
            this.lb_lpants3.TabIndex = 71;
            this.lb_lpants3.Text = "Silk Pants";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(318, 0);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(149, 166);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 70;
            this.pictureBox7.TabStop = false;
            // 
            // btn_add_lpants2
            // 
            this.btn_add_lpants2.Location = new System.Drawing.Point(152, 285);
            this.btn_add_lpants2.Name = "btn_add_lpants2";
            this.btn_add_lpants2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_lpants2.TabIndex = 69;
            this.btn_add_lpants2.Text = "Add Cart";
            this.btn_add_lpants2.UseVisualStyleBackColor = true;
            this.btn_add_lpants2.Click += new System.EventHandler(this.btn_add_lpants2_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(148, 251);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(101, 20);
            this.label10.TabIndex = 68;
            this.label10.Text = "Rp.130.000,-";
            // 
            // lb_lpants2
            // 
            this.lb_lpants2.AutoSize = true;
            this.lb_lpants2.Location = new System.Drawing.Point(148, 218);
            this.lb_lpants2.Name = "lb_lpants2";
            this.lb_lpants2.Size = new System.Drawing.Size(109, 20);
            this.lb_lpants2.TabIndex = 67;
            this.lb_lpants2.Text = "Navy Trousers";
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(158, 0);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(139, 166);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 66;
            this.pictureBox8.TabStop = false;
            // 
            // btn_add_lpants1
            // 
            this.btn_add_lpants1.Location = new System.Drawing.Point(3, 285);
            this.btn_add_lpants1.Name = "btn_add_lpants1";
            this.btn_add_lpants1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_lpants1.TabIndex = 65;
            this.btn_add_lpants1.Text = "Add Cart";
            this.btn_add_lpants1.UseVisualStyleBackColor = true;
            this.btn_add_lpants1.Click += new System.EventHandler(this.btn_add_lpants1_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(-1, 251);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 20);
            this.label11.TabIndex = 64;
            this.label11.Text = "Rp.200.000,-";
            // 
            // lb_lpants1
            // 
            this.lb_lpants1.AutoSize = true;
            this.lb_lpants1.Location = new System.Drawing.Point(-1, 218);
            this.lb_lpants1.Name = "lb_lpants1";
            this.lb_lpants1.Size = new System.Drawing.Size(92, 20);
            this.lb_lpants1.TabIndex = 63;
            this.lb_lpants1.Text = "Long Jeans";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(3, 0);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(133, 166);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9.TabIndex = 62;
            this.pictureBox9.TabStop = false;
            // 
            // panel_lpants
            // 
            this.panel_lpants.Controls.Add(this.pictureBox9);
            this.panel_lpants.Controls.Add(this.btn_add_lpants3);
            this.panel_lpants.Controls.Add(this.lb_lpants1);
            this.panel_lpants.Controls.Add(this.label9);
            this.panel_lpants.Controls.Add(this.label11);
            this.panel_lpants.Controls.Add(this.lb_lpants3);
            this.panel_lpants.Controls.Add(this.btn_add_lpants1);
            this.panel_lpants.Controls.Add(this.pictureBox7);
            this.panel_lpants.Controls.Add(this.pictureBox8);
            this.panel_lpants.Controls.Add(this.btn_add_lpants2);
            this.panel_lpants.Controls.Add(this.lb_lpants2);
            this.panel_lpants.Controls.Add(this.label10);
            this.panel_lpants.Location = new System.Drawing.Point(11, 66);
            this.panel_lpants.Name = "panel_lpants";
            this.panel_lpants.Size = new System.Drawing.Size(515, 327);
            this.panel_lpants.TabIndex = 74;
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_add_tshirt3);
            this.panel_tshirt.Controls.Add(this.pictureBox15);
            this.panel_tshirt.Controls.Add(this.label15);
            this.panel_tshirt.Controls.Add(this.lb_tshirt1);
            this.panel_tshirt.Controls.Add(this.lb_tshirt3);
            this.panel_tshirt.Controls.Add(this.label19);
            this.panel_tshirt.Controls.Add(this.pictureBox13);
            this.panel_tshirt.Controls.Add(this.btn_add_tshirt1);
            this.panel_tshirt.Controls.Add(this.btn_add_tshirt2);
            this.panel_tshirt.Controls.Add(this.pictureBox14);
            this.panel_tshirt.Controls.Add(this.label17);
            this.panel_tshirt.Controls.Add(this.lb_tshirt2);
            this.panel_tshirt.Location = new System.Drawing.Point(14, 45);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(494, 341);
            this.panel_tshirt.TabIndex = 87;
            // 
            // btn_add_tshirt3
            // 
            this.btn_add_tshirt3.Location = new System.Drawing.Point(329, 304);
            this.btn_add_tshirt3.Name = "btn_add_tshirt3";
            this.btn_add_tshirt3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_tshirt3.TabIndex = 99;
            this.btn_add_tshirt3.Text = "Add Cart";
            this.btn_add_tshirt3.UseVisualStyleBackColor = true;
            this.btn_add_tshirt3.Click += new System.EventHandler(this.btn_add_tshirt3_Click);
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox15.Image")));
            this.pictureBox15.Location = new System.Drawing.Point(16, 19);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(133, 166);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox15.TabIndex = 88;
            this.pictureBox15.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(325, 270);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(101, 20);
            this.label15.TabIndex = 98;
            this.label15.Text = "Rp.170.000,-";
            // 
            // lb_tshirt1
            // 
            this.lb_tshirt1.AutoSize = true;
            this.lb_tshirt1.Location = new System.Drawing.Point(12, 237);
            this.lb_tshirt1.Name = "lb_tshirt1";
            this.lb_tshirt1.Size = new System.Drawing.Size(129, 20);
            this.lb_tshirt1.TabIndex = 89;
            this.lb_tshirt1.Text = "T-Shirt Biru Bulat";
            // 
            // lb_tshirt3
            // 
            this.lb_tshirt3.AutoSize = true;
            this.lb_tshirt3.Location = new System.Drawing.Point(325, 237);
            this.lb_tshirt3.Name = "lb_tshirt3";
            this.lb_tshirt3.Size = new System.Drawing.Size(155, 20);
            this.lb_tshirt3.TabIndex = 97;
            this.lb_tshirt3.Text = "T-Shirt Kerah Kuning";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 270);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 20);
            this.label19.TabIndex = 90;
            this.label19.Text = "Rp.120.000,-";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(331, 19);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(149, 166);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 96;
            this.pictureBox13.TabStop = false;
            // 
            // btn_add_tshirt1
            // 
            this.btn_add_tshirt1.Location = new System.Drawing.Point(16, 304);
            this.btn_add_tshirt1.Name = "btn_add_tshirt1";
            this.btn_add_tshirt1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_tshirt1.TabIndex = 91;
            this.btn_add_tshirt1.Text = "Add Cart";
            this.btn_add_tshirt1.UseVisualStyleBackColor = true;
            this.btn_add_tshirt1.Click += new System.EventHandler(this.btn_add_tshirt1_Click);
            // 
            // btn_add_tshirt2
            // 
            this.btn_add_tshirt2.Location = new System.Drawing.Point(165, 304);
            this.btn_add_tshirt2.Name = "btn_add_tshirt2";
            this.btn_add_tshirt2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_tshirt2.TabIndex = 95;
            this.btn_add_tshirt2.Text = "Add Cart";
            this.btn_add_tshirt2.UseVisualStyleBackColor = true;
            this.btn_add_tshirt2.Click += new System.EventHandler(this.btn_add_tshirt2_Click);
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox14.Image")));
            this.pictureBox14.Location = new System.Drawing.Point(171, 19);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(139, 166);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox14.TabIndex = 92;
            this.pictureBox14.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(161, 270);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 20);
            this.label17.TabIndex = 94;
            this.label17.Text = "Rp.150.000,-";
            // 
            // lb_tshirt2
            // 
            this.lb_tshirt2.AutoSize = true;
            this.lb_tshirt2.Location = new System.Drawing.Point(161, 237);
            this.lb_tshirt2.Name = "lb_tshirt2";
            this.lb_tshirt2.Size = new System.Drawing.Size(149, 20);
            this.lb_tshirt2.TabIndex = 93;
            this.lb_tshirt2.Text = "T-Shirt Merah Muda";
            // 
            // btn_add_jewel3
            // 
            this.btn_add_jewel3.Location = new System.Drawing.Point(326, 312);
            this.btn_add_jewel3.Name = "btn_add_jewel3";
            this.btn_add_jewel3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_jewel3.TabIndex = 99;
            this.btn_add_jewel3.Text = "Add Cart";
            this.btn_add_jewel3.UseVisualStyleBackColor = true;
            this.btn_add_jewel3.Click += new System.EventHandler(this.btn_add_jewel3_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(322, 278);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 20);
            this.label12.TabIndex = 98;
            this.label12.Text = "Rp.5.000.000,-";
            // 
            // lb_jewel3
            // 
            this.lb_jewel3.AutoSize = true;
            this.lb_jewel3.Location = new System.Drawing.Point(322, 245);
            this.lb_jewel3.Name = "lb_jewel3";
            this.lb_jewel3.Size = new System.Drawing.Size(110, 20);
            this.lb_jewel3.TabIndex = 97;
            this.lb_jewel3.Text = "Diamond Ring";
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(328, 27);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(149, 166);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 96;
            this.pictureBox10.TabStop = false;
            // 
            // btn_add_jewel2
            // 
            this.btn_add_jewel2.Location = new System.Drawing.Point(162, 312);
            this.btn_add_jewel2.Name = "btn_add_jewel2";
            this.btn_add_jewel2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_jewel2.TabIndex = 95;
            this.btn_add_jewel2.Text = "Add Cart";
            this.btn_add_jewel2.UseVisualStyleBackColor = true;
            this.btn_add_jewel2.Click += new System.EventHandler(this.btn_add_jewel2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(158, 278);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(101, 20);
            this.label13.TabIndex = 94;
            this.label13.Text = "Rp.400.000,-";
            // 
            // lb_jewel2
            // 
            this.lb_jewel2.AutoSize = true;
            this.lb_jewel2.Location = new System.Drawing.Point(158, 245);
            this.lb_jewel2.Name = "lb_jewel2";
            this.lb_jewel2.Size = new System.Drawing.Size(131, 20);
            this.lb_jewel2.TabIndex = 93;
            this.lb_jewel2.Text = "Emerald Earrings";
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(168, 27);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(139, 166);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 92;
            this.pictureBox11.TabStop = false;
            // 
            // btn_add_jewel1
            // 
            this.btn_add_jewel1.Location = new System.Drawing.Point(13, 312);
            this.btn_add_jewel1.Name = "btn_add_jewel1";
            this.btn_add_jewel1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_jewel1.TabIndex = 91;
            this.btn_add_jewel1.Text = "Add Cart";
            this.btn_add_jewel1.UseVisualStyleBackColor = true;
            this.btn_add_jewel1.Click += new System.EventHandler(this.btn_add_jewel1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 278);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 20);
            this.label14.TabIndex = 90;
            this.label14.Text = "Rp.300.000,-";
            // 
            // lb_jewel1
            // 
            this.lb_jewel1.AutoSize = true;
            this.lb_jewel1.Location = new System.Drawing.Point(9, 245);
            this.lb_jewel1.Name = "lb_jewel1";
            this.lb_jewel1.Size = new System.Drawing.Size(110, 20);
            this.lb_jewel1.TabIndex = 89;
            this.lb_jewel1.Text = "Blue Necklace";
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(13, 27);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(133, 166);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 88;
            this.pictureBox12.TabStop = false;
            // 
            // panel_jewel
            // 
            this.panel_jewel.Controls.Add(this.pictureBox12);
            this.panel_jewel.Controls.Add(this.btn_add_jewel3);
            this.panel_jewel.Controls.Add(this.lb_jewel1);
            this.panel_jewel.Controls.Add(this.label12);
            this.panel_jewel.Controls.Add(this.label14);
            this.panel_jewel.Controls.Add(this.lb_jewel3);
            this.panel_jewel.Controls.Add(this.btn_add_jewel1);
            this.panel_jewel.Controls.Add(this.pictureBox10);
            this.panel_jewel.Controls.Add(this.pictureBox11);
            this.panel_jewel.Controls.Add(this.btn_add_jewel2);
            this.panel_jewel.Controls.Add(this.lb_jewel2);
            this.panel_jewel.Controls.Add(this.label13);
            this.panel_jewel.Location = new System.Drawing.Point(14, 39);
            this.panel_jewel.Name = "panel_jewel";
            this.panel_jewel.Size = new System.Drawing.Size(517, 368);
            this.panel_jewel.TabIndex = 100;
            // 
            // btn_add_shoes3
            // 
            this.btn_add_shoes3.Location = new System.Drawing.Point(331, 303);
            this.btn_add_shoes3.Name = "btn_add_shoes3";
            this.btn_add_shoes3.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shoes3.TabIndex = 112;
            this.btn_add_shoes3.Text = "Add Cart";
            this.btn_add_shoes3.UseVisualStyleBackColor = true;
            this.btn_add_shoes3.Click += new System.EventHandler(this.btn_add_shoes3_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(327, 269);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(101, 20);
            this.label21.TabIndex = 111;
            this.label21.Text = "Rp.250.000,-";
            // 
            // lb_shoes3
            // 
            this.lb_shoes3.AutoSize = true;
            this.lb_shoes3.Location = new System.Drawing.Point(327, 236);
            this.lb_shoes3.Name = "lb_shoes3";
            this.lb_shoes3.Size = new System.Drawing.Size(91, 20);
            this.lb_shoes3.TabIndex = 110;
            this.lb_shoes3.Text = "Long Boots";
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox16.Image")));
            this.pictureBox16.Location = new System.Drawing.Point(333, 18);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(149, 166);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox16.TabIndex = 109;
            this.pictureBox16.TabStop = false;
            this.pictureBox16.Click += new System.EventHandler(this.pictureBox16_Click);
            // 
            // btn_add_shoes2
            // 
            this.btn_add_shoes2.Location = new System.Drawing.Point(167, 303);
            this.btn_add_shoes2.Name = "btn_add_shoes2";
            this.btn_add_shoes2.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shoes2.TabIndex = 108;
            this.btn_add_shoes2.Text = "Add Cart";
            this.btn_add_shoes2.UseVisualStyleBackColor = true;
            this.btn_add_shoes2.Click += new System.EventHandler(this.btn_add_shoes2_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(163, 269);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(101, 20);
            this.label22.TabIndex = 107;
            this.label22.Text = "Rp.250.000,-";
            // 
            // lb_shoes2
            // 
            this.lb_shoes2.AutoSize = true;
            this.lb_shoes2.Location = new System.Drawing.Point(163, 236);
            this.lb_shoes2.Name = "lb_shoes2";
            this.lb_shoes2.Size = new System.Drawing.Size(115, 20);
            this.lb_shoes2.TabIndex = 106;
            this.lb_shoes2.Text = "Navy Sneakers";
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox17.Image")));
            this.pictureBox17.Location = new System.Drawing.Point(173, 18);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(139, 166);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox17.TabIndex = 105;
            this.pictureBox17.TabStop = false;
            // 
            // btn_add_shoes1
            // 
            this.btn_add_shoes1.Location = new System.Drawing.Point(18, 303);
            this.btn_add_shoes1.Name = "btn_add_shoes1";
            this.btn_add_shoes1.Size = new System.Drawing.Size(97, 33);
            this.btn_add_shoes1.TabIndex = 104;
            this.btn_add_shoes1.Text = "Add Cart";
            this.btn_add_shoes1.UseVisualStyleBackColor = true;
            this.btn_add_shoes1.Click += new System.EventHandler(this.btn_add_shoes1_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(14, 269);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(101, 20);
            this.label23.TabIndex = 103;
            this.label23.Text = "Rp.200.000,-";
            // 
            // lb_shoes1
            // 
            this.lb_shoes1.AutoSize = true;
            this.lb_shoes1.Location = new System.Drawing.Point(14, 236);
            this.lb_shoes1.Name = "lb_shoes1";
            this.lb_shoes1.Size = new System.Drawing.Size(84, 20);
            this.lb_shoes1.TabIndex = 102;
            this.lb_shoes1.Text = "Pink Heels";
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox18.Image")));
            this.pictureBox18.Location = new System.Drawing.Point(18, 18);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(133, 166);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox18.TabIndex = 101;
            this.pictureBox18.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.pictureBox18);
            this.panel_shoes.Controls.Add(this.btn_add_shoes3);
            this.panel_shoes.Controls.Add(this.lb_shoes1);
            this.panel_shoes.Controls.Add(this.label21);
            this.panel_shoes.Controls.Add(this.label23);
            this.panel_shoes.Controls.Add(this.lb_shoes3);
            this.panel_shoes.Controls.Add(this.btn_add_shoes1);
            this.panel_shoes.Controls.Add(this.pictureBox16);
            this.panel_shoes.Controls.Add(this.pictureBox17);
            this.panel_shoes.Controls.Add(this.btn_add_shoes2);
            this.panel_shoes.Controls.Add(this.lb_shoes2);
            this.panel_shoes.Controls.Add(this.label22);
            this.panel_shoes.Location = new System.Drawing.Point(11, 50);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(508, 366);
            this.panel_shoes.TabIndex = 113;
            // 
            // btn_add_others
            // 
            this.btn_add_others.Enabled = false;
            this.btn_add_others.Location = new System.Drawing.Point(198, 249);
            this.btn_add_others.Name = "btn_add_others";
            this.btn_add_others.Size = new System.Drawing.Size(155, 32);
            this.btn_add_others.TabIndex = 107;
            this.btn_add_others.Text = "Add To Cart";
            this.btn_add_others.UseVisualStyleBackColor = true;
            this.btn_add_others.Click += new System.EventHandler(this.btn_add_others_Click);
            // 
            // tb_itemprice
            // 
            this.tb_itemprice.Enabled = false;
            this.tb_itemprice.Location = new System.Drawing.Point(198, 195);
            this.tb_itemprice.Name = "tb_itemprice";
            this.tb_itemprice.Size = new System.Drawing.Size(116, 26);
            this.tb_itemprice.TabIndex = 106;
            this.tb_itemprice.TextChanged += new System.EventHandler(this.tb_itemprice_TextChanged);
            // 
            // tb_itemname
            // 
            this.tb_itemname.Enabled = false;
            this.tb_itemname.Location = new System.Drawing.Point(198, 115);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(116, 26);
            this.tb_itemname.TabIndex = 105;
            this.tb_itemname.TextChanged += new System.EventHandler(this.tb_itemname_TextChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(194, 172);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(88, 20);
            this.label24.TabIndex = 104;
            this.label24.Text = "Item Price: ";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(194, 92);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(95, 20);
            this.label25.TabIndex = 103;
            this.label25.Text = "Item Name: ";
            // 
            // pBox_upload
            // 
            this.pBox_upload.Location = new System.Drawing.Point(7, 70);
            this.pBox_upload.Name = "pBox_upload";
            this.pBox_upload.Size = new System.Drawing.Size(174, 246);
            this.pBox_upload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox_upload.TabIndex = 102;
            this.pBox_upload.TabStop = false;
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(140, 19);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(105, 32);
            this.btn_upload.TabIndex = 101;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(3, 25);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(117, 20);
            this.label26.TabIndex = 100;
            this.label26.Text = "Upload Image: ";
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.label26);
            this.panel_others.Controls.Add(this.btn_add_others);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.pBox_upload);
            this.panel_others.Controls.Add(this.tb_itemprice);
            this.panel_others.Controls.Add(this.label25);
            this.panel_others.Controls.Add(this.label24);
            this.panel_others.Controls.Add(this.tb_itemname);
            this.panel_others.Location = new System.Drawing.Point(96, 53);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(409, 329);
            this.panel_others.TabIndex = 114;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(539, 438);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(82, 36);
            this.btn_delete.TabIndex = 115;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 569);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_shoes);
            this.Controls.Add(this.panel_jewel);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.panel_lpants);
            this.Controls.Add(this.panel_shirt);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgv_total);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "UNIQME";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_total)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.panel_lpants.ResumeLayout(false);
            this.panel_lpants.PerformLayout();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.panel_jewel.ResumeLayout(false);
            this.panel_jewel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBox_upload)).EndInit();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem topWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bottomWearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accesoriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelleriesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem othersToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgv_total;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.Button btn_add_pants3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lb_pants3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_add_pants2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_pants2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btn_add_pants1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_pants1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_add_shirt3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lb_shirt3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btn_add_shirt2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lb_shirt2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button btn_add_shirt1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lb_shirt1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_add_lpants3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lb_lpants3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btn_add_lpants2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lb_lpants2;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Button btn_add_lpants1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lb_lpants1;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Panel panel_lpants;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.Button btn_add_tshirt3;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lb_tshirt1;
        private System.Windows.Forms.Label lb_tshirt3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Button btn_add_tshirt1;
        private System.Windows.Forms.Button btn_add_tshirt2;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lb_tshirt2;
        private System.Windows.Forms.Button btn_add_jewel3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lb_jewel3;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.Button btn_add_jewel2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lb_jewel2;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Button btn_add_jewel1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lb_jewel1;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Panel panel_jewel;
        private System.Windows.Forms.Button btn_add_shoes3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lb_shoes3;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Button btn_add_shoes2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lb_shoes2;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Button btn_add_shoes1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lb_shoes1;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_add_others;
        private System.Windows.Forms.TextBox tb_itemprice;
        private System.Windows.Forms.TextBox tb_itemname;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.PictureBox pBox_upload;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.Button btn_delete;
    }
}

