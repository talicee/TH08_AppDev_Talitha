﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Reflection;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Runtime.Remoting.Messaging;

namespace TH08___Clothes_Shop
{
    public partial class Form1 : Form
    {
        DataTable dtbiaya = new DataTable();
        DataTable dtharga = new DataTable();
        int total = 0;
        string rupiah(double harga)
        {
            CultureInfo culture = new CultureInfo("id-ID");
            return Decimal.Parse(harga.ToString()).ToString("C", culture);
        }
        void updateHarga()
        {
            tb_subtotal.Text = rupiah(total);
            tb_total.Text = rupiah(total + (total * 0.1));
        }
        public Form1()
        {
            InitializeComponent();
            dtbiaya.Columns.Add("Item Name");
            dtbiaya.Columns.Add("Quantity");
            dtbiaya.Columns.Add("Price");
            dtbiaya.Columns.Add("Total");

            dtharga.Columns.Add("Barang");
            dtharga.Columns.Add("Harga");

            dtharga.Rows.Add("T-Shirt Biru Bulat", 120000);
            dtharga.Rows.Add("T-Shirt Merah Muda", 150000);
            dtharga.Rows.Add("T-Shirt Kerah Kuning", 170000);
            dtharga.Rows.Add("Shirt Biru", 100000);
            dtharga.Rows.Add("Shirt Hijau", 110000);
            dtharga.Rows.Add("Shirt Ungu", 120000);
            dtharga.Rows.Add("Cargo Pants", 150000);
            dtharga.Rows.Add("Army Pants", 130000);
            dtharga.Rows.Add("Retro Pants", 200000);
            dtharga.Rows.Add("Long Jeans", 200000);
            dtharga.Rows.Add("Navy Trousers", 130000);
            dtharga.Rows.Add("Long Boots", 200000);
            dtharga.Rows.Add("Pink Heels", 200000);
            dtharga.Rows.Add("Navy Sneakers", 250000);
            dtharga.Rows.Add("Long Boots", 250000);
            dtharga.Rows.Add("Blue Necklace", 300000);
            dtharga.Rows.Add("Emerald Earrings", 400000);
            dtharga.Rows.Add("Diamond Ring", 5000000);

            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;

            dgv_total.DataSource = dtbiaya;
            updateHarga();
            tb_itemprice.KeyPress += tb_itemprice_KeyPress;
        }
        //TAMPIL PANEL
        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = true;
            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_pants.Visible = true;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_lpants.Visible = true;
            panel_pants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shoes.Visible = true;
            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_jewel.Visible = false;
            panel_others.Visible = false;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_jewel.Visible = true;
            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_others.Visible = false;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_others.Visible = true;
            panel_pants.Visible = false;
            panel_lpants.Visible = false;
            panel_shirt.Visible = false;
            panel_tshirt.Visible = false;
            panel_shoes.Visible = false;
            panel_jewel.Visible = false;
        }

        //PANTS 
        int count_pants1 = 0;
        int count_pants2 = 0;
        int count_pants3 = 0;
        private void btn_add_pants1_Click(object sender, EventArgs e)
        {
            int harga = 150000;
            string convertPrice = rupiah(harga);
            if (count_pants1 == 0)
            {
                count_pants1++;
                string convertTotal = rupiah(count_pants1 * harga);
                dtbiaya.Rows.Add(lb_pants1.Text, count_pants1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_pants1++;
                string convertTotal = rupiah(count_pants1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_pants1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_pants1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                } 
            }  
        }

        private void btn_add_pants2_Click(object sender, EventArgs e)
        {
            int harga = 130000;
            string convertPrice = rupiah(harga);
            if (count_pants2 == 0)
            {
                count_pants2++;
                string convertTotal = rupiah(count_pants2 * harga);
                dtbiaya.Rows.Add(lb_pants2.Text, count_pants2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_pants2++;
                string convertTotal = rupiah(count_pants2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_pants2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_pants2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_pants3_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string convertPrice = rupiah(harga);
            if (count_pants3 == 0)
            {
                count_pants3++;
                string convertTotal = rupiah(count_pants3 * harga);
                dtbiaya.Rows.Add(lb_pants3.Text, count_pants3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_pants3++;
                string convertTotal = rupiah(count_pants3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_pants3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_pants3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        //LONG PANTS
        int count_lpants1 = 0;
        int count_lpants2 = 0;
        int count_lpants3 = 0;
        private void btn_add_lpants1_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string convertPrice = rupiah(harga);
            if (count_lpants1 == 0)
            {
                count_lpants1++;
                string convertTotal = rupiah(count_lpants1 * harga);
                dtbiaya.Rows.Add(lb_lpants1.Text, count_lpants1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_lpants1++;
                string convertTotal = rupiah(count_lpants1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_lpants1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_lpants1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_lpants2_Click(object sender, EventArgs e)
        {
            int harga = 130000;
            string convertPrice = rupiah(harga);
            if (count_lpants2 == 0)
            {
                count_lpants2++;
                string convertTotal = rupiah(count_lpants2 * harga);
                dtbiaya.Rows.Add(lb_lpants2.Text, count_lpants2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_lpants2++;
                string convertTotal = rupiah(count_lpants2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_lpants2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_lpants2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_lpants3_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string convertPrice = rupiah(harga);
            if (count_lpants3 == 0)
            {
                count_lpants3++;
                string convertTotal = rupiah(count_lpants3 * harga);
                dtbiaya.Rows.Add(lb_lpants3.Text, count_lpants3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_lpants3++;
                string convertTotal = rupiah(count_lpants3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_pants3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_lpants3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        //SHIRT
        int count_shirt1 = 0;
        int count_shirt2 = 0;
        int count_shirt3 = 0;
        private void btn_add_shirt1_Click(object sender, EventArgs e)
        {
            int harga = 100000;
            string convertPrice = rupiah(harga);
            if (count_shirt1 == 0)
            {
                count_shirt1++;
                string convertTotal = rupiah(count_shirt1 * harga);
                dtbiaya.Rows.Add(lb_shirt1.Text, count_shirt1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shirt1++;
                string convertTotal = rupiah(count_shirt1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shirt1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shirt1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_shirt2_Click(object sender, EventArgs e)
        {
            int harga = 110000;
            string convertPrice = rupiah(harga);
            if (count_shirt2 == 0)
            {
                count_shirt2++;
                string convertTotal = rupiah(count_shirt2 * harga);
                dtbiaya.Rows.Add(lb_shirt2.Text, count_shirt2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shirt2++;
                string convertTotal = rupiah(count_shirt2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shirt2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shirt2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_shirt3_Click(object sender, EventArgs e)
        {
            int harga = 120000;
            string convertPrice = rupiah(harga);
            if (count_shirt3 == 0)
            {
                count_shirt3++;
                string convertTotal = rupiah(count_shirt3 * harga);
                dtbiaya.Rows.Add(lb_shirt3.Text, count_shirt3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shirt3++;
                string convertTotal = rupiah(count_shirt3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shirt3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shirt3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }
        
        //TSHIRT
        int count_tshirt1 = 0;
        int count_tshirt2 = 0;
        int count_tshirt3 = 0;
        private void btn_add_tshirt1_Click(object sender, EventArgs e)
        {
            int harga = 120000;
            string convertPrice = rupiah(harga);
            if (count_tshirt1 == 0)
            {
                count_tshirt1++;
                string convertTotal = rupiah(count_tshirt1 * harga);
                dtbiaya.Rows.Add(lb_tshirt1.Text, count_tshirt1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_tshirt1++;
                string convertTotal = rupiah(count_tshirt1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_tshirt1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_tshirt1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_tshirt2_Click(object sender, EventArgs e)
        {
            int harga = 150000;
            string convertPrice = rupiah(harga);
            if (count_tshirt2 == 0)
            {
                count_tshirt2++;
                string convertTotal = rupiah(count_tshirt2 * harga);
                dtbiaya.Rows.Add(lb_tshirt2.Text, count_tshirt2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_tshirt2++;
                string convertTotal = rupiah(count_tshirt2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_tshirt2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_tshirt2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }

        }

        private void btn_add_tshirt3_Click(object sender, EventArgs e)
        {
            int harga = 170000;
            string convertPrice = rupiah(harga);
            if (count_tshirt3 == 0)
            {
                count_tshirt3++;
                string convertTotal = rupiah(count_tshirt3 * harga);
                dtbiaya.Rows.Add(lb_tshirt3.Text, count_tshirt3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_tshirt3++;
                string convertTotal = rupiah(count_tshirt3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_tshirt3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_tshirt3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        //JEWEL
        int count_jewel1 = 0;
        int count_jewel2 = 0;
        int count_jewel3 = 0;
        private void btn_add_jewel1_Click(object sender, EventArgs e)
        {
            int harga = 300000;
            string convertPrice = rupiah(harga);
            if (count_jewel1 == 0)
            {
                count_jewel1++;
                string convertTotal = rupiah(count_jewel1 * harga);
                dtbiaya.Rows.Add(lb_jewel1.Text, count_jewel1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_jewel1++;
                string convertTotal = rupiah(count_jewel1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_jewel1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_jewel1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_jewel2_Click(object sender, EventArgs e)
        {
            int harga = 400000;
            string convertPrice = rupiah(harga);
            if (count_jewel2 == 0)
            {
                count_jewel2++;
                string convertTotal = rupiah(count_jewel2 * harga);
                dtbiaya.Rows.Add(lb_jewel2.Text, count_jewel2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_jewel2++;
                string convertTotal = rupiah(count_jewel2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_jewel2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_jewel2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_jewel3_Click(object sender, EventArgs e)
        {
            int harga = 5000000;
            string convertPrice = rupiah(harga);
            if (count_jewel3 == 0)
            {
                count_jewel3++;
                string convertTotal = rupiah(count_jewel3 * harga);
                dtbiaya.Rows.Add(lb_jewel3.Text, count_jewel3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_jewel3++;
                string convertTotal = rupiah(count_jewel3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_jewel3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_jewel3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }
        //SHOES
        int count_shoes1 = 0;
        int count_shoes2 = 0;
        int count_shoes3 = 0;
        private void btn_add_shoes1_Click(object sender, EventArgs e)
        {
            int harga = 200000;
            string convertPrice = rupiah(harga);
            if (count_shoes1 == 0)
            {
                count_shoes1++;
                string convertTotal = rupiah(count_shoes1 * harga);
                dtbiaya.Rows.Add(lb_shoes1.Text, count_shoes1, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shoes1++;
                string convertTotal = rupiah(count_shoes1 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shoes1.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shoes1;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_shoes2_Click(object sender, EventArgs e)
        {
            int harga = 250000;
            string convertPrice = rupiah(harga);
            if (count_shoes2 == 0)
            {
                count_shoes2++;
                string convertTotal = rupiah(count_shoes2 * harga);
                dtbiaya.Rows.Add(lb_shoes2.Text, count_shoes2, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shoes2++;
                string convertTotal = rupiah(count_shoes2 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shoes2.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shoes2;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_add_shoes3_Click(object sender, EventArgs e)
        {
            int harga = 250000;
            string convertPrice = rupiah(harga);
            if (count_shoes3 == 0)
            {
                count_shoes3++;
                string convertTotal = rupiah(count_shoes3 * harga);
                dtbiaya.Rows.Add(lb_shoes3.Text, count_shoes3, convertPrice, convertTotal);
                total += harga;
                updateHarga();
            }

            else
            {
                count_shoes3++;
                string convertTotal = rupiah(count_shoes3 * harga);
                for (int i = 0; i < dtbiaya.Rows.Count; i++)
                {
                    if (dtbiaya.Rows[i][0].ToString() == lb_shoes3.Text)
                    {
                        dtbiaya.Rows[i][1] = count_shoes3;
                        dtbiaya.Rows[i][3] = convertTotal;
                        total += harga;
                        updateHarga();
                    }
                }
            }
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Image Files (*.jpg; *.jpeg; *.png; *.gif; *.bmp)|*.jpg; *.jpeg; *.png; *.gif; *.bmp|All files (*.*)|*.*";
            ofd.ShowDialog();
            pBox_upload.Image = new Bitmap(ofd.FileName);
            tb_itemname.Enabled = true;
            tb_itemprice.Enabled = true;
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void tb_itemname_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemname.Text != "" && tb_itemprice.Text != "")
            {
                btn_add_others.Enabled = true;
            }

            else
            {
                btn_add_others.Enabled = false;
            }
        }
        private void tb_itemprice_TextChanged(object sender, EventArgs e)
        {
            if (tb_itemprice.Text != "" && tb_itemname.Text != "")
            {
                btn_add_others.Enabled = true;
            }

            else
            {
                btn_add_others.Enabled = false;
            }

        }

        int count_others = 0;
        private void btn_add_others_Click(object sender, EventArgs e)
        {
            bool exit = true;
            int harga = Convert.ToInt32(tb_itemprice.Text);
            string convertPrice = rupiah(harga);
            for (int i = 0; i < dtbiaya.Rows.Count; i++)
            {
                if (dtbiaya.Rows[i][0].ToString() == tb_itemname.Text)
                {
                    exit = false;
                    count_others = Convert.ToInt32(dtbiaya.Rows[i][1]) + 1;

                    string convertTotal = rupiah(count_others * harga);
                    for (int j = 0; j < dtbiaya.Rows.Count; j++)
                    {
                        if (dtbiaya.Rows[j][0].ToString() == tb_itemname.Text)
                        {
                            dtbiaya.Rows[j][1] = count_others;
                            dtbiaya.Rows[j][3] = convertTotal;
                            total += harga;
                            updateHarga();
                        }
                    }

                }
            }
            if (exit == true)
            {
                count_others = 1;
                string convertTotal = rupiah(count_others * harga);
                dtbiaya.Rows.Add(tb_itemname.Text, count_others, convertPrice, convertTotal);
                total += harga;
                updateHarga();

            }  
        }

        int iniharga = 0;
        void cari(string item)
        {
            for (int i = 0; i < dtharga.Rows.Count; i++)
            {
                if (item == dtharga.Rows[i][0].ToString())
                {
                    int harga = Convert.ToInt16(dtharga.Rows[i][1]);
                    iniharga = harga;
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_total.Rows.Count > 0)
            {
                DataGridViewRow selectedRow = dgv_total.SelectedRows[0];
                string selectedItem = selectedRow.Cells["Item Name"].Value.ToString(); //itemm pilih

                int new_quantity = 0;
                int index = 0;
                for (int i = 0; i < dgv_total.Rows.Count; i++)
                {
                    if (selectedItem == dtbiaya.Rows[i][0].ToString()) //item name
                    {
                        DataGridViewRow s = dgv_total.SelectedRows[i];
                        index = i;
                        int quantity = Convert.ToInt32(s.Cells["Quantity"].Value);
                        new_quantity = quantity - 1;
                        dtbiaya.Rows[i][1] = new_quantity;
                    }

                }
                for (int j = 0; j < dtharga.Rows.Count; j++)
                {
                    if (selectedItem == dtharga.Rows[j][0].ToString())
                    {
                        int new_harga = new_quantity * Convert.ToInt32(dtharga.Rows[j][1]);
                        dtbiaya.Rows[index][2] = new_harga;
                        total = total - new_harga;
                    }

                }

                if (new_quantity == 0)
                {
                    for (int i = 0; i < dgv_total.Rows.Count; i++)
                    {
                        if (selectedItem == dtbiaya.Rows[i][0].ToString()) //item name
                        {
                            dtbiaya.Rows.RemoveAt(i);
                        }
                    }
                }
                
            }

            else
            {
                MessageBox.Show("You havent bought anything..");
            }
            updateHarga();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {

        }
    }
}
